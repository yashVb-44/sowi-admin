import React from 'react'

const RedirectionHandler = () => {
  return (
    <div>
      
    </div>
  )
}

export default RedirectionHandler
